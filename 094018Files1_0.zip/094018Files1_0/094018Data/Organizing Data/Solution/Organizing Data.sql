-- Step 2 Query
SELECT partnum, SUM(qty) quantity
FROM Sales
WHERE qty IS NOT NULL
GROUP BY partnum
ORDER BY SUM(qty) DESC

-- Step 3 Query
SELECT repid, SUM(qty) quantity
FROM sales
WHERE qty IS NOT NULL
GROUP BY repid
HAVING SUM(qty) >= 2000
ORDER BY SUM(qty)