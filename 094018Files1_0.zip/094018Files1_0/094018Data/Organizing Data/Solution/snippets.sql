/* -------------------------------------------------------
LESSON: Organizing Data
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 4-1 Step 2B ------------ */
SELECT bktitle, slprice
FROM Titles
ORDER BY slprice DESC, bktitle


/* ------------ SNIPPET: Activity 4-1 Step 3B ------------ */
SELECT bktitle, slprice, devcost, devcost/slprice AS breakeven_point
FROM Titles
WHERE devcost IS NOT NULL
ORDER BY devcost/slprice


/* ------------ SNIPPET: Activity 4-2 Step 1B ------------ */
SELECT repid, qty, custnum
FROM Sales
WHERE DATEPART(YEAR, sldate) = 2017


/* ------------ SNIPPET: Activity 4-2 Step 2B ------------ */
SELECT repid, qty, custnum
	, RANK() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Rank'
FROM Sales
WHERE DATEPART(YEAR, sldate) = 2017


/* ------------ SNIPPET: Activity 4-2 Step 3B ------------ */
SELECT repid, qty, custnum
	, RANK() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Rank'
	, DENSE_RANK() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Dense Rank'
FROM Sales
WHERE DATEPART(YEAR, sldate) = 2017


/* ------------ SNIPPET: Activity 4-2 Step 4B ------------ */
SELECT repid, qty, custnum
	, RANK() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Rank'
	, DENSE_RANK() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Dense Rank'
	, NTILE(5) OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Ntile'
	, ROW_NUMBER() OVER(PARTITION BY repid ORDER BY qty DESC) AS 'Row Number'
FROM Sales
WHERE DATEPART(YEAR, sldate) = 2017


/* ------------ SNIPPET: Activity 4-3 Step 1C ------------ */
SELECT repid, qty, custnum
FROM Sales
WHERE DATEPART(YEAR, sldate) = 2017
ORDER BY repid


/* ------------ SNIPPET: Activity 4-3 Step 2B ------------ */
SELECT repid, qty, custnum
FROM Sales
WHERE DATEPART(YEAR, sldate) = 2017
GROUP BY repid


/* ------------ SNIPPET: Activity 4-3 Step 3B ------------ */
SELECT repid, COUNT(DISTINCT custnum) AS #_Cust
FROM Sales
WHERE DATEPART(YEAR, sldate) = 2017
GROUP BY repid


/* ------------ SNIPPET: Activity 4-4 Step 2A ------------ */
SELECT repid, COUNT(DISTINCT custnum) AS #_Cust
FROM Sales
WHERE DATEPART(YEAR, sldate) = 2017
GROUP BY repid
HAVING SUM(qty) >= 2000


/* ------------ SNIPPET: Activity 4-5 Step 1B ------------ */
SELECT repid, custnum, SUM(qty) AS annual_total
FROM Sales
WHERE DATEPART(YEAR, sldate) = 2017
GROUP BY repid, custnum


/* ------------ SNIPPET: Activity 4-5 Step 2B ------------ */
SELECT repid, custnum, SUM(qty) AS annual_total
FROM Sales
WHERE DATEPART(YEAR, sldate) = 2017
GROUP BY repid, custnum WITH ROLLUP


/* ------------ SNIPPET: Activity 4-5 Step 2B ------------ */
SELECT LEFT(DATENAME(month, sldate), 3) AS mo, qty, repid
FROM Sales


/* ------------ SNIPPET: Activity 4-5 Step 2C ------------ */
SELECT * FROM (
	SELECT LEFT(DATENAME(month, sldate), 3) AS mo, qty, repid
	FROM Sales
) AS source


/* ------------ SNIPPET: Activity 4-5 Step 3B ------------ */
SELECT * FROM (
	SELECT LEFT(DATENAME(month, sldate), 3) AS mo, qty, repid
	FROM Sales
) AS source
PIVOT (SUM(qty) FOR mo IN (Jan,Feb,Mar,Apr,May,Jun)) AS pivoted

