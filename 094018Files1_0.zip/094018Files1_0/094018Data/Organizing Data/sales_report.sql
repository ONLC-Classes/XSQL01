
USE FullerAckerman
GO
CREATE TABLE Sales_Report (rep_name varchar(15), product varchar(10), quantity int)


INSERT INTO sales_report VALUES('Kent','Monitor',5)
INSERT INTO sales_report VALUES('Kent','CPU',5)
INSERT INTO sales_report VALUES('Amelia','CPU',3)
INSERT INTO sales_report VALUES('Amelia','Monitor',8)
INSERT INTO sales_report VALUES('Kent','Monitor',4)
INSERT INTO sales_report VALUES('Kent','CPU',6)
INSERT INTO sales_report VALUES('Amelia','CPU',8)
INSERT INTO sales_report VALUES('Amelia','Monitor',7)

