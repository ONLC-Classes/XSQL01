
-- Step 2 Query
SELECT bktitle, devcost, slprice
FROM Titles 
WHERE devcost is not null
ORDER BY bktitle ASC

-- Step 5 Query
SELECT bktitle, devcost, slprice
FROM Titles 
WHERE devcost is not null
ORDER BY bktitle ASC
FOR XML AUTO, TYPE, ELEMENTS