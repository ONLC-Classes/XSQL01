/* -------------------------------------------------------
LESSON: Working with Functions
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 3-1 Step 2B ------------ */
sp_help obsolete_titles


/* ------------ SNIPPET: Activity 3-1 Step 4B ------------ */
SELECT bktitle
	, pubdate
	, DATEPART(YEAR, pubdate) AS year
	, DATEDIFF(YEAR, pubdate, GETDATE()) AS age
FROM Obsolete_Titles
WHERE pubdate BETWEEN '1/1/1994' and '12/31/2003'


/* ------------ SNIPPET: Activity 3-1 Step 5C ------------ */
SELECT bktitle
	, pubdate
	, DATEPART(YEAR, pubdate) AS year
	, DATEDIFF(YEAR, pubdate, GETDATE()) AS age
FROM Obsolete_Titles
-- WHERE pubdate BETWEEN '1/1/1994' and '12/31/2003'
WHERE DATEPART(YEAR, pubdate) BETWEEN 1994 AND 2003


/* ------------ SNIPPET: Activity 3-2 Step 1B ------------ */
SELECT *
FROM Titles
WHERE DATEPART(YEAR, pubdate) = 2017


/* ------------ SNIPPET: Activity 3-2 Step 2B ------------ */
SELECT COUNT(bktitle) AS title_count
	, SUM(devcost) AS devcost_total
	, AVG(devcost) AS devcost_average
FROM Titles
WHERE DATEPART(YEAR, pubdate) = 2017


/* ------------ SNIPPET: Activity 3-2 Step 3B ------------ */
SELECT COUNT(*) AS #_rows
	, COUNT(bktitle) AS title_count
	, COUNT(slprice) AS price_count
	, COUNT(DISTINCT slprice) AS distinct_price_count
	, COUNT(devcost) AS devcost_count
	, SUM(devcost) AS devcost_total
	, AVG(devcost) AS devcost_average
FROM Titles
WHERE DATEPART(YEAR, pubdate) = 2017


/* ------------ SNIPPET: Activity 3-3 Step 1C ------------ */
SELECT custname
	, address AS street
	, city + ', ' + state + ' ' + zipcode AS citystatezip
FROM Customers


/* ------------ SNIPPET: Activity 3-3 Step 2B ------------ */
SELECT custname
	, address AS street
	, TRIM(city) + ', ' + state + ' ' + zipcode AS citystatezip
FROM Customers


