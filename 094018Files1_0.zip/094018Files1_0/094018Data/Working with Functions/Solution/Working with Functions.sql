-- Step 2 Query
SELECT * 
FROM Sales 
WHERE DATEPART(year, sldate) = 2017
AND DATEPART(month, sldate) BETWEEN 1 AND 6 

-- Step 3 Query
SELECT * 
FROM sales 
WHERE qty >= 400 AND DATEPART(year, sldate) = 2017
AND DATEPART(month, sldate) BETWEEN 1 AND 6 

-- Step 4 Query
SELECT SUM(qty) sum_qty, COUNT(qty) count_qty 
FROM sales 
WHERE qty >= 400 AND DATEPART(year, sldate) = 2017 
AND DATEPART(month, sldate) BETWEEN 1 AND 6 

-- Step 5 Query
SELECT * 
FROM customers 
WHERE LEN(custnum) = 4 