-- Step 3 Query
SELECT bktitle, partnum, slprice
FROM Titles
WHERE slprice BETWEEN 10 AND 30

-- Step 4 Query
SELECT *
FROM Sales 
WHERE repid LIKE 'E%' OR repid LIKE 'N%'

-- Step 5 Query
SELECT *
FROM Sales 
WHERE repid LIKE 'E%' OR repid LIKE 'N%' AND qty >= 400