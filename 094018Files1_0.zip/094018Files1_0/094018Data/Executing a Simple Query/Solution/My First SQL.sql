SELECT *
FROM titles