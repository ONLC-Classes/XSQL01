-- Connect to the Database

USE FullerAckerman

-- Queries to list all rows and columns in the Customers, Titles, Slspers, and Sales tables.

SELECT * FROM customers

SELECT * FROM titles

SELECT * FROM slspers

SELECT * FROM sales

-- Modify queries to display information about customers, 
-- titles, sales representatives, and sales details

-- Display the address of customers

SELECT custname, address, city, state, zipcode 
FROM customers

-- Display the book title, part number, and sales price from the Titles table

SELECT bktitle, partnum, slprice 
FROM titles

-- Display the representative id and their names

SELECT repid, fname, lname 
FROM slspers

-- Display the order number, part number and the quantity 
-- for each sale from the Sales table.

SELECT ordnum, partnum, qty 
FROM sales