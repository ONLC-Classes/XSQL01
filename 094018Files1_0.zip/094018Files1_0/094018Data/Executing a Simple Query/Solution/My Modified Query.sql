SELECT partnum, bktitle, slprice 
FROM titles
-- SELECT statement to retrieve a book list for sales representatives.