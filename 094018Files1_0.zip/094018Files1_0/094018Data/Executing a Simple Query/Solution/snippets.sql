/* -------------------------------------------------------
LESSON: Executing a Simple Query
---------------------------------------------------------- */


/* ------------ SNIPPET: Activity 1-1 Step 3C ------------ */
USE Pub1


/* ------------ SNIPPET: Activity 1-2 Step 2C ------------ */
USE Pub1
SELECT *
FROM Titles


/* ------------ SNIPPET: Activity 1-2 Step 5A ------------ */
USE Pub1
SELECT Titles.bktitle, Titles.slprice
FROM Titles


/* ------------ SNIPPET: Activity 1-4 Step 1D ------------ */
sp_help titles


/* ------------ SNIPPET: Activity 1-4 Step 5B ------------ */
USE Pub1
SELECT Titles.partnum, Titles.bktitle, Titles.slprice
FROM Titles


/* ------------ SNIPPET: Activity 1-4 Step 7B ------------ */
USE Pub1

-- List of current book prices
SELECT Titles.partnum, Titles.bktitle, Titles.slprice
FROM Titles


