NOTE TO THE INSTRUCTOR:



This folder contains the data files and PowerPoint slides for your course.  

Right-click to view the folder structure.


POWERPOINT SLIDES:

The slides for the course were created with PowerPoint 2016.
	

View the slides using PowerPoint or other compatible software.



	
